# QR Code Detection

QR code detection requires downloading an external plugin and placing it inside this directory. For full instructions, see [Setup](../../doc/SpectatorView.Setup.md).